#define HAVE_MALLOC_H 1
#define HAVE_MMX 1
#define ARCH_X86 1
#define SYS_LINUX 1
#define HAVE_PTHREAD 1
#define HAVE_LOG2F 1
#define fseek fseeko
#define ftell ftello
#define BIT_DEPTH 8
#define X264_VERSION " r1666 d058f37"
#define X264_POINTVER "0.102.1666 d058f37"
